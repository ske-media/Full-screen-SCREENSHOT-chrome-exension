// src/shared/idb.ts
var DB_NAME = "full-page-capture";
var DB_VERSION = 1;
var STORE = "captures";
function openDb() {
  return new Promise((resolve, reject) => {
    const req = indexedDB.open(DB_NAME, DB_VERSION);
    req.onupgradeneeded = () => {
      const db = req.result;
      if (!db.objectStoreNames.contains(STORE)) {
        db.createObjectStore(STORE, { keyPath: "id" });
      }
    };
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error ?? new Error("Ouverture IndexedDB impossible"));
  });
}
async function saveCapture(capture) {
  const db = await openDb();
  const record = {
    ...capture,
    id: capture.id ?? crypto.randomUUID(),
    createdAt: Date.now()
  };
  await new Promise((resolve, reject) => {
    const tx = db.transaction(STORE, "readwrite");
    tx.objectStore(STORE).put(record);
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error ?? new Error("\xC9criture IndexedDB impossible"));
  });
  db.close();
  return record.id;
}

// src/shared/types.ts
var FPC_CHANNEL = "fpc";
var MAX_CANVAS_DIM = 16384;
var MAX_CANVAS_PIXELS = 4e7;
var MAX_SLICES = 100;

// src/shared/stitch.ts
async function stitchSlices(slices, metrics) {
  if (slices.length === 0) {
    throw new Error("Aucune tranche \xE0 assembler.");
  }
  const bitmaps = await Promise.all(
    slices.map(async (slice) => {
      const bmp = await createImageBitmap(slice.blob);
      return { bmp, y: slice.y };
    })
  );
  try {
    const sample = bitmaps[0].bmp;
    const viewportHeight = Math.max(1, metrics.viewportHeight);
    const pxPerCssY = sample.height / viewportHeight;
    const fullWidth = sample.width;
    const fullHeight = Math.max(sample.height, Math.round(metrics.pageHeight * pxPerCssY));
    let scale = 1;
    if (fullWidth > MAX_CANVAS_DIM || fullHeight > MAX_CANVAS_DIM) {
      scale = Math.min(MAX_CANVAS_DIM / fullWidth, MAX_CANVAS_DIM / fullHeight, 1);
    }
    if (fullWidth * fullHeight * scale * scale > MAX_CANVAS_PIXELS) {
      scale = Math.min(scale, Math.sqrt(MAX_CANVAS_PIXELS / (fullWidth * fullHeight)));
    }
    const outW = Math.max(1, Math.round(fullWidth * scale));
    const outH = Math.max(1, Math.round(fullHeight * scale));
    const canvas = new OffscreenCanvas(outW, outH);
    const ctx = canvas.getContext("2d");
    if (!ctx) {
      throw new Error("OffscreenCanvas 2D indisponible dans le service worker.");
    }
    ctx.imageSmoothingEnabled = true;
    ctx.imageSmoothingQuality = "high";
    ctx.fillStyle = "#ffffff";
    ctx.fillRect(0, 0, outW, outH);
    for (const { bmp, y } of bitmaps) {
      const destY = y * pxPerCssY * scale;
      const destW = bmp.width * scale;
      const destH = bmp.height * scale;
      ctx.drawImage(bmp, 0, destY, destW, destH);
    }
    const blob = await canvas.convertToBlob({ type: "image/png" });
    return { blob, width: outW, height: outH, scaled: scale < 0.999 };
  } finally {
    for (const { bmp } of bitmaps) {
      bmp.close();
    }
  }
}

// src/shared/urls.ts
var RESTRICTED = [
  /^chrome:\/\//i,
  /^chrome-extension:\/\//i,
  /^edge:\/\//i,
  /^about:/i,
  /^https:\/\/chromewebstore\.google\.com/i,
  /^https:\/\/chrome\.google\.com\/webstore/i
];
function isRestrictedUrl(url) {
  return RESTRICTED.some((re) => re.test(url));
}

// src/background/capture-orchestrator.ts
async function sendToTab(tabId, message) {
  let lastError;
  for (let attempt = 0; attempt < 4; attempt++) {
    try {
      return await chrome.tabs.sendMessage(tabId, message);
    } catch (err) {
      lastError = err;
      await delay(120);
    }
  }
  throw lastError instanceof Error ? lastError : new Error("Le script de capture n'a pas pu communiquer avec la page.");
}
function delay(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}
async function captureFullPage(tab, onProgress) {
  if (tab.id === void 0 || tab.windowId === void 0) {
    throw new Error("Onglet introuvable.");
  }
  const tabId = tab.id;
  const windowId = tab.windowId;
  const url = tab.url ?? "";
  if (!url || isRestrictedUrl(url)) {
    throw new Error(
      "Cette page ne peut pas \xEAtre captur\xE9e (page syst\xE8me Chrome ou Web Store)."
    );
  }
  await chrome.scripting.executeScript({
    target: { tabId },
    files: ["content.js"]
  });
  const metrics = await sendToTab(tabId, {
    channel: FPC_CHANNEL,
    type: "PREPARE"
  });
  if (metrics.error) {
    throw new Error(metrics.error);
  }
  const slices = [];
  let truncated = false;
  try {
    let y = 0;
    let pageHeight = metrics.pageHeight;
    const viewportHeight = metrics.viewportHeight;
    let index = 0;
    let fixedHidden = false;
    if (viewportHeight <= 0) {
      throw new Error("Hauteur de viewport invalide.");
    }
    while (index < MAX_SLICES) {
      const estimatedTotal = Math.max(
        1,
        Math.ceil(pageHeight / viewportHeight),
        index + 1
      );
      onProgress({
        current: index + 1,
        total: estimatedTotal,
        message: `Capture de la section ${index + 1}\u2026`
      });
      const scrolled = await sendToTab(tabId, {
        channel: FPC_CHANNEL,
        type: "SCROLL_TO",
        y
      });
      if (scrolled.pageHeight) {
        pageHeight = scrolled.pageHeight;
      }
      if (index > 0 && !fixedHidden) {
        await sendToTab(tabId, { channel: FPC_CHANNEL, type: "HIDE_FIXED" });
        fixedHidden = true;
      }
      const dataUrl = await chrome.tabs.captureVisibleTab(windowId, {
        format: "png"
      });
      const blob = await (await fetch(dataUrl)).blob();
      slices.push({ blob, y });
      index += 1;
      if (y + viewportHeight >= pageHeight - 1) {
        break;
      }
      const nextY = y + viewportHeight;
      if (nextY + viewportHeight > pageHeight) {
        const bottomY = Math.max(0, pageHeight - viewportHeight);
        if (bottomY > y) {
          y = bottomY;
          continue;
        }
        break;
      }
      y = nextY;
    }
    if (index >= MAX_SLICES && y + viewportHeight < pageHeight - 1) {
      truncated = true;
    }
    onProgress({
      current: slices.length,
      total: slices.length,
      message: "Assemblage de l'image\u2026"
    });
    const stitched = await stitchSlices(slices, {
      viewportWidth: metrics.viewportWidth,
      viewportHeight,
      pageWidth: metrics.pageWidth,
      pageHeight
    });
    const id = await saveCapture({
      blob: stitched.blob,
      width: stitched.width,
      height: stitched.height,
      scaled: stitched.scaled,
      truncated,
      title: tab.title || "capture",
      url
    });
    return {
      id,
      width: stitched.width,
      height: stitched.height,
      scaled: stitched.scaled,
      truncated
    };
  } finally {
    try {
      await sendToTab(tabId, { channel: FPC_CHANNEL, type: "CLEANUP" });
    } catch {
    }
  }
}

// src/background/service-worker.ts
var capturing = false;
chrome.runtime.onMessage.addListener(
  (message, _sender, sendResponse) => {
    if (!message?.type) return;
    if (message.type === "GET_CAPTURE_STATUS") {
      sendResponse({ capturing });
      return;
    }
    if (message.type !== "START_CAPTURE") return;
    if (capturing) {
      sendResponse({ ok: false, error: "Une capture est d\xE9j\xE0 en cours." });
      return;
    }
    capturing = true;
    runCapture(message.tabId).catch((err) => {
      const text = err instanceof Error ? err.message : String(err);
      void notify({ type: "CAPTURE_ERROR", message: text });
    }).finally(() => {
      capturing = false;
      void chrome.action.setBadgeText({ text: "" });
    });
    sendResponse({ ok: true });
  }
);
async function runCapture(tabId) {
  const tab = tabId ? await chrome.tabs.get(tabId) : await resolveTargetTab();
  if (!tab) {
    throw new Error("Aucun onglet actif \xE0 capturer.");
  }
  if (tab.windowId !== void 0) {
    await chrome.windows.update(tab.windowId, { focused: true });
  }
  await chrome.action.setBadgeBackgroundColor({ color: "#4f46e5" });
  const result = await captureFullPage(tab, ({ current, total, message }) => {
    const pct = total > 0 ? Math.round(current / total * 100) : 0;
    void chrome.action.setBadgeText({ text: `${Math.min(99, pct)}` });
    void notify({
      type: "CAPTURE_PROGRESS",
      current,
      total,
      message
    });
  });
  await notify({ type: "CAPTURE_DONE", captureId: result.id });
  const editorUrl = chrome.runtime.getURL(
    `editor.html?id=${encodeURIComponent(result.id)}`
  );
  await chrome.tabs.create({ url: editorUrl });
}
async function resolveTargetTab() {
  const [active] = await chrome.tabs.query({
    active: true,
    lastFocusedWindow: true
  });
  if (active && !active.url?.startsWith("chrome-extension://")) {
    return active;
  }
  const all = await chrome.tabs.query({ lastFocusedWindow: true });
  return all.find((t) => t.active && !t.url?.startsWith("chrome-extension://")) ?? active;
}
function notify(payload) {
  return chrome.runtime.sendMessage(payload).catch(() => {
  });
}
