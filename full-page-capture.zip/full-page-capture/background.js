// src/shared/idb.ts
var DB_NAME = "full-page-capture";
var DB_VERSION = 1;
var STORE = "captures";
function openDb() {
  return new Promise((resolve, reject) => {
    const req = indexedDB.open(DB_NAME, DB_VERSION);
    req.onupgradeneeded = () => {
      const db = req.result;
      if (!db.objectStoreNames.contains(STORE)) {
        db.createObjectStore(STORE, { keyPath: "id" });
      }
    };
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error ?? new Error("Ouverture IndexedDB impossible"));
  });
}
async function saveCapture(capture) {
  const db = await openDb();
  const record = {
    ...capture,
    id: capture.id ?? crypto.randomUUID(),
    createdAt: Date.now()
  };
  await new Promise((resolve, reject) => {
    const tx = db.transaction(STORE, "readwrite");
    tx.objectStore(STORE).put(record);
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error ?? new Error("\xC9criture IndexedDB impossible"));
  });
  db.close();
  return record.id;
}

// src/shared/types.ts
var FPC_CHANNEL = "fpc";
var MAX_SLICES = 100;

// src/shared/urls.ts
var RESTRICTED = [
  /^chrome:\/\//i,
  /^chrome-extension:\/\//i,
  /^edge:\/\//i,
  /^about:/i,
  /^https:\/\/chromewebstore\.google\.com/i,
  /^https:\/\/chrome\.google\.com\/webstore/i
];
function isRestrictedUrl(url) {
  return RESTRICTED.some((re) => re.test(url));
}

// src/background/capture-orchestrator.ts
async function sendToTab(tabId, message) {
  let lastError;
  for (let attempt = 0; attempt < 4; attempt++) {
    try {
      return await chrome.tabs.sendMessage(tabId, message);
    } catch (err) {
      lastError = err;
      await delay(150);
    }
  }
  throw lastError instanceof Error ? lastError : new Error("Le script de capture n'a pas pu communiquer avec la page.");
}
function delay(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}
function dataUrlToBlob(dataUrl) {
  const comma = dataUrl.indexOf(",");
  if (comma < 0) throw new Error("Capture d'\xE9cran invalide.");
  const header = dataUrl.slice(0, comma);
  const data = dataUrl.slice(comma + 1);
  const mime = /data:([^;]+)/.exec(header)?.[1] ?? "image/png";
  const binary = atob(data);
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
  return new Blob([bytes], { type: mime });
}
async function captureVisible(windowId, tabId) {
  let lastError;
  for (let attempt = 0; attempt < 5; attempt++) {
    try {
      await chrome.tabs.update(tabId, { active: true });
      if (attempt > 0) await delay(350 * attempt);
      const dataUrl = await chrome.tabs.captureVisibleTab(windowId, { format: "png" });
      if (dataUrl && dataUrl.startsWith("data:")) return dataUrl;
      lastError = new Error("Capture vide.");
    } catch (err) {
      lastError = err;
      try {
        const fallbackWin = await chrome.windows.getLastFocused();
        if (fallbackWin.id !== void 0 && fallbackWin.id !== windowId) {
          const fallback = await chrome.tabs.captureVisibleTab(fallbackWin.id, {
            format: "png"
          });
          if (fallback && fallback.startsWith("data:")) return fallback;
        }
      } catch (fallbackErr) {
        lastError = fallbackErr;
      }
    }
  }
  const detail = lastError instanceof Error ? lastError.message : String(lastError ?? "");
  throw new Error(
    detail ? `Impossible de photographier l'onglet (${detail}).` : "Impossible de photographier l'onglet."
  );
}
async function captureFullPage(tab, onProgress) {
  if (tab.id === void 0 || tab.windowId === void 0) {
    throw new Error("Onglet introuvable.");
  }
  const tabId = tab.id;
  const windowId = tab.windowId;
  const url = tab.url ?? "";
  if (!url || isRestrictedUrl(url)) {
    throw new Error(
      "Cette page ne peut pas \xEAtre captur\xE9e (page syst\xE8me Chrome ou Web Store)."
    );
  }
  await chrome.scripting.executeScript({
    target: { tabId },
    files: ["content.js"]
  });
  const metrics = await sendToTab(tabId, {
    channel: FPC_CHANNEL,
    type: "PREPARE"
  });
  if (metrics.error) {
    throw new Error(metrics.error);
  }
  const slices = [];
  let truncated = false;
  try {
    let y = 0;
    let pageHeight = metrics.pageHeight;
    const viewportHeight = metrics.viewportHeight;
    let index = 0;
    let fixedHidden = false;
    if (viewportHeight <= 0) {
      throw new Error("Hauteur de viewport invalide.");
    }
    try {
      while (index < MAX_SLICES) {
        const estimatedTotal = Math.max(
          1,
          Math.ceil(pageHeight / viewportHeight),
          index + 1
        );
        onProgress({
          current: index + 1,
          total: estimatedTotal,
          message: `Capture de la section ${index + 1}\u2026`
        });
        await chrome.tabs.update(tabId, { active: true });
        const scrolled = await sendToTab(tabId, {
          channel: FPC_CHANNEL,
          type: "SCROLL_TO",
          y
        });
        if (scrolled.pageHeight) {
          pageHeight = scrolled.pageHeight;
        }
        if (index > 0 && !fixedHidden) {
          await sendToTab(tabId, { channel: FPC_CHANNEL, type: "HIDE_FIXED" });
          fixedHidden = true;
        }
        const dataUrl = await captureVisible(windowId, tabId);
        slices.push({ blob: dataUrlToBlob(dataUrl), y });
        index += 1;
        if (y + viewportHeight >= pageHeight - 1) {
          break;
        }
        const nextY = y + viewportHeight;
        if (nextY + viewportHeight > pageHeight) {
          const bottomY = Math.max(0, pageHeight - viewportHeight);
          if (bottomY > y) {
            y = bottomY;
            continue;
          }
          break;
        }
        y = nextY;
      }
    } catch (err) {
      if (slices.length === 0) throw err;
      truncated = true;
    }
    if (index >= MAX_SLICES && y + viewportHeight < pageHeight - 1) {
      truncated = true;
    }
    if (slices.length === 0) {
      throw new Error("Aucune capture n'a pu \xEAtre enregistr\xE9e.");
    }
    onProgress({
      current: slices.length,
      total: slices.length,
      message: "Ouverture de l'\xE9diteur\u2026"
    });
    const id = await saveCapture({
      slices,
      metrics: {
        viewportWidth: metrics.viewportWidth,
        viewportHeight,
        pageWidth: metrics.pageWidth,
        pageHeight
      },
      width: 0,
      height: 0,
      scaled: false,
      truncated,
      title: tab.title || "capture",
      url
    });
    return { id, truncated, sliceCount: slices.length };
  } finally {
    try {
      await sendToTab(tabId, { channel: FPC_CHANNEL, type: "CLEANUP" });
    } catch {
    }
  }
}

// src/background/service-worker.ts
var capturing = false;
chrome.runtime.onMessage.addListener(
  (message, _sender, sendResponse) => {
    if (!message?.type) return;
    if (message.type === "GET_CAPTURE_STATUS") {
      sendResponse({ capturing });
      return;
    }
    if (message.type !== "START_CAPTURE") return;
    if (capturing) {
      sendResponse({ ok: false, error: "Une capture est d\xE9j\xE0 en cours." });
      return;
    }
    capturing = true;
    runCapture(message.tabId).catch((err) => {
      const text = err instanceof Error ? err.message : String(err);
      void chrome.storage.local.set({ lastCaptureError: text });
      void notify({ type: "CAPTURE_ERROR", message: text });
      void openEditor({ error: text });
      void chrome.action.setBadgeBackgroundColor({ color: "#b91c1c" });
      void chrome.action.setBadgeText({ text: "ERR" });
    }).finally(() => {
      capturing = false;
      setTimeout(() => {
        void chrome.action.setBadgeText({ text: "" });
      }, 4e3);
    });
    sendResponse({ ok: true });
  }
);
async function runCapture(tabId) {
  const tab = tabId ? await chrome.tabs.get(tabId) : await resolveTargetTab();
  if (!tab) {
    throw new Error("Aucun onglet actif \xE0 capturer.");
  }
  if (tab.windowId !== void 0) {
    await chrome.windows.update(tab.windowId, { focused: true });
  }
  if (tab.id !== void 0) {
    await chrome.tabs.update(tab.id, { active: true });
  }
  await chrome.action.setBadgeBackgroundColor({ color: "#4f46e5" });
  const result = await captureFullPage(tab, ({ current, total, message }) => {
    const pct = total > 0 ? Math.round(current / total * 100) : 0;
    void chrome.action.setBadgeText({ text: `${Math.min(99, pct)}` });
    void notify({
      type: "CAPTURE_PROGRESS",
      current,
      total,
      message
    });
  });
  await notify({ type: "CAPTURE_DONE", captureId: result.id });
  await openEditor({ id: result.id });
}
function editorPageUrl(params) {
  const url = new URL(chrome.runtime.getURL("editor.html"));
  if (params.id) url.searchParams.set("id", params.id);
  if (params.error) url.searchParams.set("error", params.error);
  return url.toString();
}
async function openEditor(params) {
  await chrome.tabs.create({ url: editorPageUrl(params), active: true });
}
async function resolveTargetTab() {
  const [active] = await chrome.tabs.query({
    active: true,
    lastFocusedWindow: true
  });
  if (active && !active.url?.startsWith("chrome-extension://")) {
    return active;
  }
  const all = await chrome.tabs.query({ lastFocusedWindow: true });
  return all.find((t) => t.active && !t.url?.startsWith("chrome-extension://")) ?? active;
}
function notify(payload) {
  return chrome.runtime.sendMessage(payload).catch(() => {
  });
}
