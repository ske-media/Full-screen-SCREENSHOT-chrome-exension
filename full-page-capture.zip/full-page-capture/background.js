(() => {
  // src/shared/idb.ts
  var DB_NAME = "full-page-capture";
  var DB_VERSION = 1;
  var STORE = "captures";
  function openDb() {
    return new Promise((resolve, reject) => {
      const req = indexedDB.open(DB_NAME, DB_VERSION);
      req.onupgradeneeded = () => {
        const db = req.result;
        if (!db.objectStoreNames.contains(STORE)) {
          db.createObjectStore(STORE, { keyPath: "id" });
        }
      };
      req.onsuccess = () => resolve(req.result);
      req.onerror = () => reject(req.error ?? new Error("Ouverture IndexedDB impossible"));
    });
  }
  async function saveCapture(capture) {
    const db = await openDb();
    const record = {
      ...capture,
      id: capture.id ?? crypto.randomUUID(),
      createdAt: Date.now()
    };
    await new Promise((resolve, reject) => {
      const tx = db.transaction(STORE, "readwrite");
      tx.objectStore(STORE).put(record);
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error ?? new Error("\xC9criture IndexedDB impossible"));
    });
    db.close();
    return record.id;
  }

  // src/shared/types.ts
  var MAX_SLICES = 100;

  // src/shared/urls.ts
  var RESTRICTED = [
    /^chrome:\/\//i,
    /^chrome-extension:\/\//i,
    /^edge:\/\//i,
    /^about:/i,
    /^https:\/\/chromewebstore\.google\.com/i,
    /^https:\/\/chrome\.google\.com\/webstore/i
  ];
  function isRestrictedUrl(url) {
    return RESTRICTED.some((re) => re.test(url));
  }

  // src/background/page-inject.ts
  async function injectPrepare() {
    const STYLE_ID = "__fpc_style_v3";
    const STATE_KEY = "__fpc_state_v3";
    const w = window;
    w[STATE_KEY] = {
      scrollX: window.scrollX,
      scrollY: window.scrollY || document.documentElement.scrollTop || 0,
      scrollBehavior: document.documentElement.style.scrollBehavior,
      htmlOverflow: document.documentElement.style.overflow,
      bodyOverflow: document.body?.style.overflow ?? "",
      fixed: []
    };
    document.documentElement.style.scrollBehavior = "auto";
    if (!document.getElementById(STYLE_ID)) {
      const style = document.createElement("style");
      style.id = STYLE_ID;
      style.textContent = "html::-webkit-scrollbar,body::-webkit-scrollbar{display:none!important;width:0!important;height:0!important}html,body{scrollbar-width:none!important;-ms-overflow-style:none!important}";
      document.documentElement.appendChild(style);
    }
    const saved = [];
    for (const node of document.querySelectorAll("body *")) {
      if (!(node instanceof HTMLElement) || node.id === STYLE_ID) continue;
      const position = getComputedStyle(node).position;
      if (position === "fixed" || position === "sticky") {
        saved.push({ el: node, visibility: node.style.visibility });
      }
    }
    w[STATE_KEY].fixed = saved;
    window.scrollTo(0, 0);
    await new Promise((resolve) => {
      requestAnimationFrame(() => {
        requestAnimationFrame(() => setTimeout(resolve, 250));
      });
    });
    const html = document.documentElement;
    const body = document.body;
    return {
      pageWidth: Math.max(html.scrollWidth, body?.scrollWidth ?? 0, html.clientWidth),
      pageHeight: Math.max(html.scrollHeight, body?.scrollHeight ?? 0, html.clientHeight),
      viewportWidth: window.innerWidth,
      viewportHeight: window.innerHeight,
      dpr: window.devicePixelRatio || 1,
      scrollX: window.scrollX,
      scrollY: window.scrollY || html.scrollTop || 0
    };
  }
  async function injectScrollTo(y) {
    document.documentElement.style.scrollBehavior = "auto";
    window.scrollTo(0, y);
    await new Promise((resolve) => {
      requestAnimationFrame(() => {
        requestAnimationFrame(() => setTimeout(resolve, 250));
      });
    });
    const html = document.documentElement;
    const body = document.body;
    return {
      pageWidth: Math.max(html.scrollWidth, body?.scrollWidth ?? 0, html.clientWidth),
      pageHeight: Math.max(html.scrollHeight, body?.scrollHeight ?? 0, html.clientHeight),
      viewportWidth: window.innerWidth,
      viewportHeight: window.innerHeight,
      dpr: window.devicePixelRatio || 1,
      scrollX: window.scrollX,
      scrollY: window.scrollY || html.scrollTop || 0
    };
  }
  async function injectHideFixed() {
    const STATE_KEY = "__fpc_state_v3";
    const w = window;
    const fixed = w[STATE_KEY]?.fixed ?? [];
    for (const item of fixed) {
      item.el.style.setProperty("visibility", "hidden", "important");
    }
    await new Promise((resolve) => setTimeout(resolve, 80));
  }
  function injectCleanup() {
    const STYLE_ID = "__fpc_style_v3";
    const STATE_KEY = "__fpc_state_v3";
    const w = window;
    const state = w[STATE_KEY];
    if (state) {
      for (const item of state.fixed) {
        if (item.visibility) item.el.style.visibility = item.visibility;
        else item.el.style.removeProperty("visibility");
      }
      document.documentElement.style.scrollBehavior = state.scrollBehavior;
      document.documentElement.style.overflow = state.htmlOverflow;
      if (document.body) document.body.style.overflow = state.bodyOverflow;
      window.scrollTo(state.scrollX, state.scrollY);
      w[STATE_KEY] = void 0;
    }
    document.getElementById(STYLE_ID)?.remove();
  }

  // src/background/capture-orchestrator.ts
  function delay(ms) {
    return new Promise((resolve) => setTimeout(resolve, ms));
  }
  function withTimeout(promise, ms, label) {
    return new Promise((resolve, reject) => {
      const timer = setTimeout(() => reject(new Error(label)), ms);
      promise.then(
        (value) => {
          clearTimeout(timer);
          resolve(value);
        },
        (err) => {
          clearTimeout(timer);
          reject(err);
        }
      );
    });
  }
  async function runInPage(tabId, func) {
    const results = await chrome.scripting.executeScript({
      target: { tabId },
      func
    });
    const first = results[0];
    if (!first) throw new Error("La page n'a pas r\xE9pondu.");
    return first.result;
  }
  async function runInPageArg(tabId, func, arg) {
    const results = await chrome.scripting.executeScript({
      target: { tabId },
      func,
      args: [arg]
    });
    const first = results[0];
    if (!first) throw new Error("La page n'a pas r\xE9pondu.");
    return first.result;
  }
  function dataUrlToBlob(dataUrl) {
    const comma = dataUrl.indexOf(",");
    if (comma < 0) throw new Error("Capture d'\xE9cran invalide.");
    const header = dataUrl.slice(0, comma);
    const data = dataUrl.slice(comma + 1);
    const mime = /data:([^;]+)/.exec(header)?.[1] ?? "image/png";
    const binary = atob(data);
    const bytes = new Uint8Array(binary.length);
    for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
    return new Blob([bytes], { type: mime });
  }
  async function captureVisible(windowId) {
    let lastError;
    for (let attempt = 0; attempt < 3; attempt++) {
      if (attempt > 0) await delay(400 * attempt);
      try {
        const dataUrl = await withTimeout(
          chrome.tabs.captureVisibleTab(windowId, { format: "png" }),
          2500,
          "D\xE9lai d\xE9pass\xE9 pendant la photo de l'onglet."
        );
        if (dataUrl && dataUrl.startsWith("data:")) return dataUrl;
        lastError = new Error("Capture vide.");
      } catch (err) {
        lastError = err;
      }
    }
    const detail = lastError instanceof Error ? lastError.message : String(lastError ?? "");
    throw new Error(
      detail ? `Impossible de photographier l'onglet (${detail}).` : "Impossible de photographier l'onglet."
    );
  }
  async function captureFullPage(tab, onProgress) {
    if (tab.id === void 0 || tab.windowId === void 0) {
      throw new Error("Onglet introuvable.");
    }
    const tabId = tab.id;
    const windowId = tab.windowId;
    const url = tab.url ?? "";
    if (!url || isRestrictedUrl(url)) {
      throw new Error(
        "Cette page ne peut pas \xEAtre captur\xE9e (page syst\xE8me Chrome ou Web Store). Ouvrez un site http(s)."
      );
    }
    onProgress({ current: 0, total: 1, message: "Pr\xE9paration de la page\u2026" });
    const metrics = await runInPage(tabId, injectPrepare);
    const slices = [];
    let truncated = false;
    try {
      let y = 0;
      let pageHeight = metrics.pageHeight;
      const viewportHeight = metrics.viewportHeight;
      let index = 0;
      let fixedHidden = false;
      if (viewportHeight <= 0) {
        throw new Error("Hauteur de viewport invalide.");
      }
      try {
        while (index < MAX_SLICES) {
          const estimatedTotal = Math.max(
            1,
            Math.ceil(pageHeight / viewportHeight),
            index + 1
          );
          onProgress({
            current: index + 1,
            total: estimatedTotal,
            message: `Capture de la section ${index + 1}\u2026`
          });
          const scrolled = await runInPageArg(tabId, injectScrollTo, y);
          if (scrolled.pageHeight) pageHeight = scrolled.pageHeight;
          if (index > 0 && !fixedHidden) {
            await runInPage(tabId, injectHideFixed);
            fixedHidden = true;
          }
          const dataUrl = await captureVisible(windowId);
          slices.push({ blob: dataUrlToBlob(dataUrl), y });
          index += 1;
          if (y + viewportHeight >= pageHeight - 1) break;
          const nextY = y + viewportHeight;
          if (nextY + viewportHeight > pageHeight) {
            const bottomY = Math.max(0, pageHeight - viewportHeight);
            if (bottomY > y) {
              y = bottomY;
              continue;
            }
            break;
          }
          y = nextY;
        }
      } catch (err) {
        if (slices.length === 0) throw err;
        truncated = true;
      }
      if (index >= MAX_SLICES && y + viewportHeight < pageHeight - 1) {
        truncated = true;
      }
      if (slices.length === 0) {
        throw new Error("Aucune capture n'a pu \xEAtre enregistr\xE9e.");
      }
      onProgress({
        current: slices.length,
        total: slices.length,
        message: "Ouverture de l'\xE9diteur\u2026"
      });
      const id = await saveCapture({
        slices,
        metrics: {
          viewportWidth: metrics.viewportWidth,
          viewportHeight,
          pageWidth: metrics.pageWidth,
          pageHeight
        },
        width: 0,
        height: 0,
        scaled: false,
        truncated,
        title: tab.title || "capture",
        url
      });
      return { id, truncated, sliceCount: slices.length };
    } finally {
      try {
        await runInPage(tabId, injectCleanup);
      } catch {
      }
    }
  }

  // src/background/service-worker.ts
  var capturing = false;
  chrome.runtime.onMessage.addListener(
    (message, _sender, sendResponse) => {
      if (!message?.type) return;
      if (message.type === "GET_CAPTURE_STATUS") {
        sendResponse({ capturing });
        return;
      }
      if (message.type !== "START_CAPTURE") return;
      if (capturing) {
        sendResponse({ ok: false, error: "Une capture est d\xE9j\xE0 en cours." });
        return;
      }
      capturing = true;
      void chrome.action.setBadgeBackgroundColor({ color: "#4f46e5" });
      void chrome.action.setBadgeText({ text: "\u2026" });
      runCapture(message.tabId).catch((err) => {
        const text = err instanceof Error ? err.message : String(err);
        void chrome.storage.local.set({ lastCaptureError: text });
        void notify({ type: "CAPTURE_ERROR", message: text });
        void openEditor({ error: text });
        void chrome.action.setBadgeBackgroundColor({ color: "#b91c1c" });
        void chrome.action.setBadgeText({ text: "ERR" });
      }).finally(() => {
        capturing = false;
        setTimeout(() => {
          void chrome.action.setBadgeText({ text: "" });
        }, 5e3);
      });
      sendResponse({ ok: true });
    }
  );
  async function runCapture(tabId) {
    const stopKeepAlive = startKeepAlive();
    try {
      await delay2(350);
      const tab = tabId ? await chrome.tabs.get(tabId) : await resolveTargetTab();
      if (!tab?.id) {
        throw new Error("Aucun onglet actif \xE0 capturer.");
      }
      const result = await captureFullPage(tab, ({ current, total }) => {
        const pct = total > 0 ? Math.round(current / total * 100) : 0;
        void chrome.action.setBadgeText({ text: `${Math.min(99, pct)}` });
      });
      await notify({ type: "CAPTURE_DONE", captureId: result.id });
      await openEditor({ id: result.id });
    } finally {
      stopKeepAlive();
    }
  }
  function startKeepAlive() {
    const timer = setInterval(() => {
      void chrome.runtime.getPlatformInfo();
    }, 4e3);
    return () => clearInterval(timer);
  }
  function delay2(ms) {
    return new Promise((resolve) => setTimeout(resolve, ms));
  }
  function editorPageUrl(params) {
    const url = new URL(chrome.runtime.getURL("editor.html"));
    if (params.id) url.searchParams.set("id", params.id);
    if (params.error) url.searchParams.set("error", params.error);
    return url.toString();
  }
  async function openEditor(params) {
    await chrome.tabs.create({ url: editorPageUrl(params), active: true });
  }
  async function resolveTargetTab() {
    const [active] = await chrome.tabs.query({
      active: true,
      lastFocusedWindow: true
    });
    if (active && !active.url?.startsWith("chrome-extension://")) {
      return active;
    }
    const all = await chrome.tabs.query({ lastFocusedWindow: true });
    return all.find((t) => t.active && !t.url?.startsWith("chrome-extension://")) ?? active;
  }
  function notify(payload) {
    return chrome.runtime.sendMessage(payload).catch(() => void 0);
  }
})();
